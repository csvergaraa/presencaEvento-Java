package vo;

public class EventoVO {
    
}
