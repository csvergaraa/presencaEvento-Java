package vo;

public class AlunoVO {
    
}
